APP_NAME = "NILKON"
APP_VERSION = "1.10.0"
APP_TAGLINE = "Your music. Your frequency."
